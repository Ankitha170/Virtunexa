// Toggle menu
document.getElementById('menu-toggle').addEventListener('click', function () {
    document.querySelector('.nav-links').classList.toggle('show');
  });
  
  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
      document.querySelector('.nav-links').classList.remove('show');
    });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const loginLink = document.getElementById('loginLink');
    const loginModal = document.getElementById('loginModal');
    const closeModal = document.getElementById('closeModal');
  
    loginLink.addEventListener('click', function(e) {
      e.preventDefault();  // prevent default anchor link behavior
      loginModal.style.display = 'block';  // show modal
    });
  
    closeModal.addEventListener('click', function() {
      loginModal.style.display = 'none';  // hide modal
    });
  
    // Hide modal when clicking outside modal-content
    window.addEventListener('click', function(event) {
      if (event.target === loginModal) {
        loginModal.style.display = 'none';
      }
    });
  });
  