// Navigation toggle for small screens
const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');

navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('show');
});

// Smooth scrolling for nav links
document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const targetId = link.getAttribute('href').slice(1);
    const targetSection = document.getElementById(targetId);
    targetSection.scrollIntoView({ behavior: 'smooth' });
    navLinks.classList.remove('show'); // close nav on click
  });
});

// Expense tracking logic
const expenseForm = document.getElementById('expense-form');
const expenseList = document.getElementById('expense-list');
const totalExpenseEl = document.getElementById('total-expense');
const filterTimeframe = document.getElementById('filter-timeframe');
const filterCategory = document.getElementById('filter-category');
const ctx = document.getElementById('expense-chart').getContext('2d');

let expenses = [];

function addExpense(expense) {
  expenses.push(expense);
  renderExpenses();
  updateChart();
}

function renderExpenses() {
  expenseList.innerHTML = '';
  let total = 0;
  expenses.forEach(({desc, amount, category, date}) => {
    const li = document.createElement('li');
    li.textContent = `${date} - ${desc} (${category}): $${amount.toFixed(2)}`;
    expenseList.appendChild(li);
    total += amount;
  });
  totalExpenseEl.textContent = total.toFixed(2);
}

// Chart.js setup
let chart;

function filterExpenses() {
  const timeframe = filterTimeframe.value;
  const category = filterCategory.value;

  const now = new Date();
  return expenses.filter(exp => {
    const expDate = new Date(exp.date);
    // Filter by category
    if (category !== 'all' && exp.category !== category) return false;

    if (timeframe === 'month') {
      return expDate.getMonth() === now.getMonth() && expDate.getFullYear() === now.getFullYear();
    }
    if (timeframe === 'week') {
      // Get current week range (Sunday to Saturday)
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());
      const lastDayOfWeek = new Date(firstDayOfWeek);
      lastDayOfWeek.setDate(firstDayOfWeek.getDate() + 6);
      return expDate >= firstDayOfWeek && expDate <= lastDayOfWeek;
    }
    return true;
  });
}

function groupExpensesByCategory(filteredExpenses) {
  const grouped = {};
  filteredExpenses.forEach(({category, amount}) => {
    if (!grouped[category]) grouped[category] = 0;
    grouped[category] += amount;
  });
  return grouped;
}

function updateChart() {
  const filtered = filterExpenses();
  const grouped = groupExpensesByCategory(filtered);

  const labels = Object.keys(grouped);
  const data = Object.values(grouped);

  if (chart) chart.destroy();

  chart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        label: 'Expenses',
        data,
        backgroundColor: [
          '#007bff', '#28a745', '#ffc107', '#dc3545', '#6c757d'
        ],
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
        }
      }
    }
  });
}

expenseForm.addEventListener('submit', e => {
  e.preventDefault();
  const desc = document.getElementById('desc').value.trim();
  const amount = parseFloat(document.getElementById('amount').value);
  const category = document.getElementById('category').value;
  const date = document.getElementById('date').value;

  if (!desc || !amount || !category || !date) return;

  addExpense({desc, amount, category, date});

  expenseForm.reset();
});

filterTimeframe.addEventListener('change', updateChart);
filterCategory.addEventListener('change', updateChart);

// Initialize with empty chart
updateChart();
